
from core.omega_control import pick_best_task, execute_task

def main():
    prompts = ["write poem", "get weather", "play chess", "summarize article"]
    best_task = pick_best_task(prompts)
    output = execute_task(best_task)
    print(f"[Output]: {output}")

if __name__ == "__main__":
    main()
