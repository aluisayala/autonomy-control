
import random

def omega_score(prompt):
    base_scores = {
        "write poem": 0.9,
        "get weather": 0.9,
        "play chess": 0.8,
        "summarize article": 0.9
    }
    return base_scores.get(prompt, 0.5) + random.uniform(-0.05, 0.05)

def pick_best_task(prompts):
    scores = {p: omega_score(p) for p in prompts}
    best_task = max(scores, key=scores.get)
    print(f"Ω scores: {scores}")
    print(f"[Agent]: Selected → '{best_task}'")
    return best_task

def execute_task(task):
    if task == "write poem":
        return "Roses are red, violets are blue..."
    elif task == "get weather":
        return "The weather today is sunny with a high of 75°F."
    elif task == "play chess":
        return "Playing chess: e4 e5 Nf3 Nc6"
    elif task == "summarize article":
        return "This article explains the basics of AI autonomy control."
    else:
        return "Task not recognized."
