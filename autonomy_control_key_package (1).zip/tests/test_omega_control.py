
import pytest
from core.omega_control import omega_score, pick_best_task, execute_task

def test_omega_score_basic():
    prompt = "write poem"
    score = omega_score(prompt)
    assert isinstance(score, float)
    assert 0 <= score <= 1

def test_pick_best_task_returns_highest_score():
    prompts = ["write poem", "play chess", "get weather"]
    best = pick_best_task(prompts)
    assert best in prompts

def test_execute_task_known():
    result = execute_task("write poem")
    assert "Roses are red" in result or isinstance(result, str)

def test_execute_task_unknown():
    result = execute_task("unknown task")
    assert result == "Task not recognized."
